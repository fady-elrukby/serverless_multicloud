const app = require("../app");
const middlewares = require("../config")();
const package = require("../../package.json");

module.exports = {
    sayHello: app.use(middlewares, (context) => {
        const { req } = context;
        const name = req.query.get("name");

        if (name) {
          context.send(`Hello ${name}`, 200);
        }
        else {
          context.send("Please pass a name on the query string or in the request body", 400);
        }
    })
  };